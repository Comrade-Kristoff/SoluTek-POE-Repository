package com.jff.jffapp;

import java.util.Calendar;
import java.util.Date;

public class Census {
    private String EMIS;

    private String schoolName;

    private String principalName;

    private String attendee;

    private String dateTaken;

    private int afrMale0;

    private int afrMale16;

    private int afrMale19;

    private int afrMale36;

    private int afrFem0;

    private int afrFem16;

    private int afrFem19;

    private int afrFem36;

    private int colMale0;

    private int colMale16;

    private int colMale19;

    private int colMale36;

    private int colFem0;

    private int colFem16;

    private int colFem19;

    private int colFem36;

    private int indMale0;

    private int indMale16;

    private int indMale19;

    private int indMale36;

    private int indFem0;

    private int indFem16;

    private int indFem19;

    private int indFem36;

    private int whiMale0;

    private int whiMale16;

    private int whiMale19;

    private int whiMale36;

    private int whiFem0;

    private int whiFem16;

    private int whiFem19;

    private int whiFem36;

    private int othMale0;

    private int othMale16;

    private int othMale19;

    private int othMale36;

    private int othFem0;

    private int othFem16;

    private int othFem19;

    private int othFem36;

    private int totalAfr;

    private int totalCol;

    private int totalInd;

    private int totalWhi;

    private int totalOth;

    private int totalMale0;

    private int totalMale16;

    private int totalMale19;

    private int totalMale36;

    private int totalFem0;

    private int totalFem16;

    private int totalFem19;

    private int totalFem36;

    public Census() {}

    public Census(String EMIS, String schoolName, String principalName, String attendee, String dateTaken, int afrMale0, int afrMale16, int afrMale19, int afrMale36, int afrFem0, int afrFem16, int afrFem19, int afrFem36, int colMale0, int colMale16, int colMale19, int colMale36, int colFem0, int colFem16, int colFem19, int colFem36, int indMale0, int indMale16, int indMale19, int indMale36, int indFem0, int indFem16, int indFem19, int indFem36, int whiMale0, int whiMale16, int whiMale19, int whiMale36, int whiFem0, int whiFem16, int whiFem19, int whiFem36, int othMale0, int othMale16, int othMale19, int othMale36, int othFem0, int othFem16, int othFem19, int othFem36, int totalAfr, int totalCol, int totalInd, int totalWhi, int totalOth, int totalMale0, int totalMale16, int totalMale19, int totalMale36, int totalFem0, int totalFem16, int totalFem19, int totalFem36) {
        this.EMIS = EMIS;
        this.schoolName = schoolName;
        this.principalName = principalName;
        this.attendee = attendee;
        this.dateTaken = dateTaken;
        this.afrMale0 = afrMale0;
        this.afrMale16 = afrMale16;
        this.afrMale19 = afrMale19;
        this.afrMale36 = afrMale36;
        this.afrFem0 = afrFem0;
        this.afrFem16 = afrFem16;
        this.afrFem19 = afrFem19;
        this.afrFem36 = afrFem36;
        this.colMale0 = colMale0;
        this.colMale16 = colMale16;
        this.colMale19 = colMale19;
        this.colMale36 = colMale36;
        this.colFem0 = colFem0;
        this.colFem16 = colFem16;
        this.colFem19 = colFem19;
        this.colFem36 = colFem36;
        this.indMale0 = indMale0;
        this.indMale16 = indMale16;
        this.indMale19 = indMale19;
        this.indMale36 = indMale36;
        this.indFem0 = indFem0;
        this.indFem16 = indFem16;
        this.indFem19 = indFem19;
        this.indFem36 = indFem36;
        this.whiMale0 = whiMale0;
        this.whiMale16 = whiMale16;
        this.whiMale19 = whiMale19;
        this.whiMale36 = whiMale36;
        this.whiFem0 = whiFem0;
        this.whiFem16 = whiFem16;
        this.whiFem19 = whiFem19;
        this.whiFem36 = whiFem36;
        this.othMale0 = othMale0;
        this.othMale16 = othMale16;
        this.othMale19 = othMale19;
        this.othMale36 = othMale36;
        this.othFem0 = othFem0;
        this.othFem16 = othFem16;
        this.othFem19 = othFem19;
        this.othFem36 = othFem36;
        this.totalAfr = totalAfr;
        this.totalCol = totalCol;
        this.totalInd = totalInd;
        this.totalWhi = totalWhi;
        this.totalOth = totalOth;
        this.totalMale0 = totalMale0;
        this.totalMale16 = totalMale16;
        this.totalMale19 = totalMale19;
        this.totalMale36 = totalMale36;
        this.totalFem0 = totalFem0;
        this.totalFem16 = totalFem16;
        this.totalFem19 = totalFem19;
        this.totalFem36 = totalFem36;
    }

    public String getEMIS() {
        return EMIS;
    }

    public void setEMIS(String EMIS) {
        this.EMIS = EMIS;
    }

    public String getSchoolName() {
        return schoolName;
    }

    public void setSchoolName(String schoolName) {
        this.schoolName = schoolName;
    }

    public String getPrincipalName() {
        return principalName;
    }

    public void setPrincipalName(String principalName) {
        this.principalName = principalName;
    }

    public String getAttendee() {
        return attendee;
    }

    public String getDateTaken() {
        return dateTaken;
    }

    public void setDateTaken(String dateTaken) {
        this.dateTaken = dateTaken;
    }

    public void setAttendee(String attendee) {
        this.attendee = attendee;
    }

    public int getAfrMale0() {
        return afrMale0;
    }

    public void setAfrMale0(int afrMale0) {
        this.afrMale0 = afrMale0;
    }

    public int getAfrMale16() {
        return afrMale16;
    }

    public void setAfrMale16(int afrMale16) {
        this.afrMale16 = afrMale16;
    }

    public int getAfrMale19() {
        return afrMale19;
    }

    public void setAfrMale19(int afrMale19) {
        this.afrMale19 = afrMale19;
    }

    public int getAfrMale36() {
        return afrMale36;
    }

    public void setAfrMale36(int afrMale36) {
        this.afrMale36 = afrMale36;
    }

    public int getAfrFem0() {
        return afrFem0;
    }

    public void setAfrFem0(int afrFem0) {
        this.afrFem0 = afrFem0;
    }

    public int getAfrFem16() {
        return afrFem16;
    }

    public void setAfrFem16(int afrFem16) {
        this.afrFem16 = afrFem16;
    }

    public int getAfrFem19() {
        return afrFem19;
    }

    public void setAfrFem19(int afrFem19) {
        this.afrFem19 = afrFem19;
    }

    public int getAfrFem36() {
        return afrFem36;
    }

    public void setAfrFem36(int afrFem36) {
        this.afrFem36 = afrFem36;
    }

    public int getColMale0() {
        return colMale0;
    }

    public void setColMale0(int colMale0) {
        this.colMale0 = colMale0;
    }

    public int getColMale16() {
        return colMale16;
    }

    public void setColMale16(int colMale16) {
        this.colMale16 = colMale16;
    }

    public int getColMale19() {
        return colMale19;
    }

    public void setColMale19(int colMale19) {
        this.colMale19 = colMale19;
    }

    public int getColMale36() {
        return colMale36;
    }

    public void setColMale36(int colMale36) {
        this.colMale36 = colMale36;
    }

    public int getColFem0() {
        return colFem0;
    }

    public void setColFem0(int colFem0) {
        this.colFem0 = colFem0;
    }

    public int getColFem16() {
        return colFem16;
    }

    public void setColFem16(int colFem16) {
        this.colFem16 = colFem16;
    }

    public int getColFem19() {
        return colFem19;
    }

    public void setColFem19(int colFem19) {
        this.colFem19 = colFem19;
    }

    public int getColFem36() {
        return colFem36;
    }

    public void setColFem36(int colFem36) {
        this.colFem36 = colFem36;
    }

    public int getIndMale0() {
        return indMale0;
    }

    public void setIndMale0(int indMale0) {
        this.indMale0 = indMale0;
    }

    public int getIndMale16() {
        return indMale16;
    }

    public void setIndMale16(int indMale16) {
        this.indMale16 = indMale16;
    }

    public int getIndMale19() {
        return indMale19;
    }

    public void setIndMale19(int indMale19) {
        this.indMale19 = indMale19;
    }

    public int getIndMale36() {
        return indMale36;
    }

    public void setIndMale36(int indMale36) {
        this.indMale36 = indMale36;
    }

    public int getIndFem0() {
        return indFem0;
    }

    public void setIndFem0(int indFem0) {
        this.indFem0 = indFem0;
    }

    public int getIndFem16() {
        return indFem16;
    }

    public void setIndFem16(int indFem16) {
        this.indFem16 = indFem16;
    }

    public int getIndFem19() {
        return indFem19;
    }

    public void setIndFem19(int indFem19) {
        this.indFem19 = indFem19;
    }

    public int getIndFem36() {
        return indFem36;
    }

    public void setIndFem36(int indFem36) {
        this.indFem36 = indFem36;
    }

    public int getWhiMale0() {
        return whiMale0;
    }

    public void setWhiMale0(int whiMale0) {
        this.whiMale0 = whiMale0;
    }

    public int getWhiMale16() {
        return whiMale16;
    }

    public void setWhiMale16(int whiMale16) {
        this.whiMale16 = whiMale16;
    }

    public int getWhiMale19() {
        return whiMale19;
    }

    public void setWhiMale19(int whiMale19) {
        this.whiMale19 = whiMale19;
    }

    public int getWhiMale36() {
        return whiMale36;
    }

    public void setWhiMale36(int whiMale36) {
        this.whiMale36 = whiMale36;
    }

    public int getWhiFem0() {
        return whiFem0;
    }

    public void setWhiFem0(int whiFem0) {
        this.whiFem0 = whiFem0;
    }

    public int getWhiFem16() {
        return whiFem16;
    }

    public void setWhiFem16(int whiFem16) {
        this.whiFem16 = whiFem16;
    }

    public int getWhiFem19() {
        return whiFem19;
    }

    public void setWhiFem19(int whiFem19) {
        this.whiFem19 = whiFem19;
    }

    public int getWhiFem36() {
        return whiFem36;
    }

    public void setWhiFem36(int whiFem36) {
        this.whiFem36 = whiFem36;
    }

    public int getOthMale0() {
        return othMale0;
    }

    public void setOthMale0(int othMale0) {
        this.othMale0 = othMale0;
    }

    public int getOthMale16() {
        return othMale16;
    }

    public void setOthMale16(int othMale16) {
        this.othMale16 = othMale16;
    }

    public int getOthMale19() {
        return othMale19;
    }

    public void setOthMale19(int othMale19) {
        this.othMale19 = othMale19;
    }

    public int getOthMale36() {
        return othMale36;
    }

    public void setOthMale36(int othMale36) {
        this.othMale36 = othMale36;
    }

    public int getOthFem0() {
        return othFem0;
    }

    public void setOthFem0(int othFem0) {
        this.othFem0 = othFem0;
    }

    public int getOthFem16() {
        return othFem16;
    }

    public void setOthFem16(int othFem16) {
        this.othFem16 = othFem16;
    }

    public int getOthFem19() {
        return othFem19;
    }

    public void setOthFem19(int othFem19) {
        this.othFem19 = othFem19;
    }

    public int getOthFem36() {
        return othFem36;
    }

    public void setOthFem36(int othFem36) {
        this.othFem36 = othFem36;
    }

    public int getTotalAfr() {
        return afrFem0 + afrFem16 + afrFem19 + afrFem36 + afrMale0 + afrMale16 + afrMale19 + afrMale36;
    }

    public int getTotalCol() {
        return colFem0 + colFem16 + colFem19 + colFem36 + colMale0 + colMale16 + colMale19 + colMale36;
    }

    public int getTotalInd() {
        return indFem0 + indFem16 + indFem19 + indFem36 + indMale0 + indMale16 + indMale19 + indMale36;
    }

    public int getTotalWhi() {
        return whiFem0 + whiFem16 + whiFem19 + whiFem36 + whiMale0 + whiMale16 + whiMale19 + whiMale36;
    }

    public int getTotalOth() {
        return othFem0 + othFem16 + othFem19 + othFem36 + othMale0 + othMale16 + othMale19 + othMale36;
    }

    public int getTotalMale0() {
        return afrMale0 + colMale0 + indMale0 + othMale0 + whiMale0;
    }

    public int getTotalMale16() {
        return afrMale16 + colMale16 + indMale16 + othMale16 + whiMale16;
    }

    public int getTotalMale19() {
        return afrMale19 + colMale19 + indMale19 + othMale19 + whiMale19;
    }

    public int getTotalMale36() {
        return afrMale36 + colMale36 + indMale36 + othMale36 + whiMale36;
    }

    public int getTotalFem0() {
        return afrFem0 + colFem0 + indFem0 + othFem0 + whiFem0;
    }

    public int getTotalFem16() {
        return afrFem16 + colFem16 + indFem16 + othFem16 + whiFem16;
    }

    public int getTotalFem19() {
        return afrFem19 + colFem19 + indFem19 + othFem19 + whiFem19;
    }

    public int getTotalFem36() {
        return afrFem36 + colFem36 + indFem36 + othFem36 + whiFem36;
    }
}
