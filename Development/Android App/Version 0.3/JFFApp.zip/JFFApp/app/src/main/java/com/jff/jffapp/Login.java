package com.jff.jffapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class Login extends AppCompatActivity {

    private FirebaseAuth mAuth;

    Button loginBtn;
    Button regBtn;
    EditText userName;
    EditText userPass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        mAuth = FirebaseAuth.getInstance();

        loginBtn = findViewById(R.id.btnLogin);
        regBtn = findViewById(R.id.btnToReg);
        userName = findViewById(R.id.edtUsername);
        userPass = findViewById(R.id.edtUserPass);
    }

    public void toRegister(View view){
        Intent intentToReg = new Intent(Login.this, Register.class);
        startActivity((intentToReg));
    }

    public void LoginUser(View view){
        try {
            String UserNameLog = userName.getText().toString().trim();
            String UserPassLog = userPass.getText().toString().trim();
            if (TextUtils.isEmpty(UserNameLog)) {
                Toast.makeText(this, "Please enter a valid Email address", Toast.LENGTH_SHORT).show();
                userName.requestFocus();
                return;
            }
            if (TextUtils.isEmpty(UserPassLog)) {
                Toast.makeText(this, "Please enter a password", Toast.LENGTH_SHORT).show();
                userPass.requestFocus();
                return;
            }
            //Firebase login
            mAuth.signInWithEmailAndPassword(UserNameLog, UserPassLog).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if (task.isSuccessful()) {
                        Toast.makeText(Login.this, "Login Successful", Toast.LENGTH_SHORT).show();
                        userName.setText("");
                        userPass.setText("");
                        Intent logIntent = new Intent(Login.this, MainActivity.class);
                        startActivity(logIntent);
                    } else {
                        Toast.makeText(Login.this, "Could not log you in", Toast.LENGTH_SHORT).show();
                        userPass.setText("");
                    }
                }
            });
        }
        catch(Exception e) {
            Toast.makeText(this, "Contact your administrator", Toast.LENGTH_SHORT).show();
        }
        Intent toMain = new Intent(Login.this, MainActivity.class);
        startActivity((toMain));
    }


}