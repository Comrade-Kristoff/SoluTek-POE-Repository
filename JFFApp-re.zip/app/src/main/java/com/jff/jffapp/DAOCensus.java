package com.jff.jffapp;

import android.app.Application;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;

public class DAOCensus extends Application
{
    private DatabaseReference dbRef;
    public String cenEmis = "";
    saveEMIS se = new saveEMIS();

    public DAOCensus(){
        FirebaseDatabase db = FirebaseDatabase.getInstance();
        dbRef = db.getReference(Census.class.getSimpleName());
    }

    //Setting up the table and all the values.
    public Task<Void> AddInitial(Census cen, String cenEmisAdd)
    {
        se.setSomeVariable(cenEmisAdd);
        cenEmis = se.getSomeVariable();
        String m = dbRef.orderByKey().limitToLast(1).get().toString();
        return dbRef.child(cenEmisAdd).setValue(cen);//.setValue(cen);
    }

    //Intended for updating all data for African ethnicity and age groups.
    public Task<Void> UpdateAfr(HashMap<String, Object> hashMap, String emisNum)
    {
        dbRef = FirebaseDatabase.getInstance().getReference("Census").child(emisNum);
        return dbRef.updateChildren(hashMap);
    }

    //Intended for updating all data for Coloured ethnicity and age groups.
    public Task<Void> UpdateCol(HashMap<String, Object> hashMap, String emisNum)
    {
        dbRef = FirebaseDatabase.getInstance().getReference("Census").child(emisNum);
        return dbRef.updateChildren(hashMap);
    }

    //Intended for updating all data for Indian ethnicity and age groups.
    public Task<Void> UpdateInd(HashMap<String, Object> hashMap, String emisNum)
    {
        dbRef = FirebaseDatabase.getInstance().getReference("Census").child(emisNum);
        return dbRef.updateChildren(hashMap);
    }

    //Intended for updating all data for White ethnicity and age groups.
    public Task<Void> UpdateWhi(HashMap<String, Object> hashMap, String emisNum)
    {
        dbRef = FirebaseDatabase.getInstance().getReference("Census").child(emisNum);
        return dbRef.updateChildren(hashMap);
    }

    //Intended for updating all data for Other ethnicity and age groups.
    public Task<Void> UpdateOth(HashMap<String, Object> hashMap, String emisNum)
    {
        dbRef = FirebaseDatabase.getInstance().getReference("Census").child(emisNum);
        return dbRef.updateChildren(hashMap);
    }

    public Task<Void> UpdateTotals(HashMap<String, Object> hashMap, String emisNum)
    {
        dbRef = FirebaseDatabase.getInstance().getReference("Census").child(emisNum);
        return dbRef.updateChildren(hashMap);
    }



}
