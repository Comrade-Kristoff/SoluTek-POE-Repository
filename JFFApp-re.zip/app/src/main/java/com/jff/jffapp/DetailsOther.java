package com.jff.jffapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;

public class DetailsOther extends AppCompatActivity {

    Button addOthBtn;
    EditText OthMale0, OthMale16, OthMale19, OthMale36;
    EditText OthFem0, OthFem16, OthFem19, OthFem36;

    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference myRef = database.getReference("jffcensus-default-rtdb");
    private String emisNum;
    private static final String TAG = "MainActivity";
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details_other);



        DAOCensus dao = new DAOCensus();

        //Oth DEMOGRAPHIC
        addOthBtn = findViewById(R.id.btnAddOth);
        OthMale0 =  findViewById(R.id.edtOthM0);
        OthMale16 = findViewById(R.id.edtOthM16);
        OthMale19 = findViewById(R.id.edtOthM19);
        OthMale36 = findViewById(R.id.edtOthM36);
        OthFem0 =   findViewById(R.id.edtOthF0);
        OthFem16 =  findViewById(R.id.edtOthF16);
        OthFem19 =  findViewById(R.id.edtOthF19);
        OthFem36 =  findViewById(R.id.edtOthF36);

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            emisNum = extras.getString("EMIS");
        }
        ///////////

        //Intended to update relevant data
        addOthBtn.setOnClickListener(view ->
        {
            HashMap<String, Object> hashMap = new HashMap<>();
            hashMap.put("othMale0", OthMale0.getText().toString());
            hashMap.put("othMale16",OthMale16.getText().toString());
            hashMap.put("othMale19",OthMale19.getText().toString());
            hashMap.put("othMale36",OthMale36.getText().toString());
            hashMap.put("othFem0",  OthFem0.getText().toString());
            hashMap.put("othFem16", OthFem16.getText().toString());
            hashMap.put("othFem19", OthFem19.getText().toString());
            hashMap.put("othFem36", OthFem36.getText().toString());
            //dao.
            dao.UpdateOth(hashMap, emisNum);

            Toast.makeText(this, "Update Complete!", Toast.LENGTH_SHORT).show();

        });
        
    }
}