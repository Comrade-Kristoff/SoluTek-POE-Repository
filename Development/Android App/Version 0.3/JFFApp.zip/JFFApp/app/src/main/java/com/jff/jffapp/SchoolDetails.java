package com.jff.jffapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DateFormat;
import java.util.Calendar;

public class SchoolDetails extends AppCompatActivity {

    public static final String EMIS_TAG = "com.jff.jffapp.example.EXTRA_TEXT";

    Button newSchoolBtn;
    TextView dateDisplay;
    EditText EMISNum;
    EditText schoolName;
    EditText cenAttendee;
    EditText schoolPrincipal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_school_details);

        newSchoolBtn = findViewById(R.id.btnNewSchool);
        EMISNum = findViewById(R.id.edtEMIS);
        schoolPrincipal = findViewById(R.id.edtPrincipal);
        schoolName = findViewById(R.id.edtSchool);
        cenAttendee = findViewById(R.id.edtAttendee);
        dateDisplay = findViewById(R.id.tvCurrentDate);

        Calendar calendar = Calendar.getInstance();
        String censusDate = DateFormat.getDateInstance().format(calendar.getTime());

        dateDisplay.setText(censusDate);

        //Calling data access object class
        DAOCensus dao = new DAOCensus();

        //Creates the table
        newSchoolBtn.setOnClickListener(view ->
        {
        if (!EMISNum.getText().toString().isEmpty() && !schoolName.getText().toString().isEmpty() &&
            !schoolPrincipal.getText().toString().isEmpty() && !cenAttendee.getText().toString().isEmpty())
        {
            Census cen = new Census(EMISNum.getText().toString(), schoolName.getText().toString(),
                    schoolPrincipal.getText().toString(), cenAttendee.getText().toString(), dateDisplay.getText().toString(),
                    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

            dao.AddInitial(cen, EMISNum.getText().toString()).addOnSuccessListener(suc ->
            {
                Toast.makeText(this, "Successfully Added", Toast.LENGTH_SHORT).show();
            }).addOnFailureListener(er ->
            {
                Toast.makeText(this, "Failed to add", Toast.LENGTH_SHORT).show();
            });

            Intent intentToCreate = new Intent(SchoolDetails.this, CatSelect.class);
            intentToCreate.putExtra("EMIS", EMISNum.getText().toString());

            startActivity((intentToCreate));
        }
        else
        {
            Toast.makeText(this, "Please Fill in All Details!", Toast.LENGTH_SHORT).show();
        }


        });
    }
}