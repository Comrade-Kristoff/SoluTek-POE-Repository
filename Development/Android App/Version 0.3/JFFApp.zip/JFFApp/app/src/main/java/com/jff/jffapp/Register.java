package com.jff.jffapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class Register extends AppCompatActivity {

    private FirebaseAuth mAuth;

    Button registerUser;
    Button returnLogin;
    EditText userName;
    EditText userPass;
    EditText userConPass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        registerUser = findViewById(R.id.btnReg);
        returnLogin = findViewById(R.id.btnRetLogin);
        userName = findViewById(R.id.edtRegUser);
        userPass = findViewById(R.id.edtRegPass);
        userConPass = findViewById(R.id.edtRegPassCon);

        mAuth = FirebaseAuth.getInstance();

        registerUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (view.getId() == R.id.btnReg)
                {
                    String email = userName.getText().toString().trim();
                    String password = userPass.getText().toString().trim();
                    String conPassword = userConPass.getText().toString().trim();

                    if (TextUtils.isEmpty(email))
                    {
                        Toast.makeText(Register.this, "Please enter an email address", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    if (TextUtils.isEmpty(password))
                    {
                        Toast.makeText(Register.this, "Please enter your password", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    if (TextUtils.isEmpty(conPassword))
                    {
                        Toast.makeText(Register.this, "Please confirm your password", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    if (password.length() < 6 || conPassword.length() < 6)
                    {
                        Toast.makeText(Register.this, "Passwords must be a minimum of 6 characters", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    //Registering the user
                    if (conPassword.equals(password))
                    {
                        //Create the user account
                        mAuth.createUserWithEmailAndPassword(email, password)
                                .addOnCompleteListener(Register.this, new OnCompleteListener<AuthResult>() {
                                    @Override
                                    public void onComplete(@NonNull Task<AuthResult> task) {
                                        if (task.isSuccessful())
                                        {
                                            startActivity(new Intent(Register.this, Login.class));
                                            Toast.makeText(Register.this, "Registration was successful", Toast.LENGTH_SHORT).show();
                                            finish();
                                        }
                                        else
                                        {
                                            Toast.makeText(Register.this, "Account already exists", Toast.LENGTH_SHORT).show();
                                        }
                                    }
                                });
                    }
                    else
                    {
                        Toast.makeText(Register.this, "Passwords do not match", Toast.LENGTH_SHORT).show();
                        clearPasswords();
                    }
                }
            }
        });
    }

    private void clearPasswords(){
        userPass.setText(null);
        userConPass.setText(null);
    }
}