package com.jff.jffapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;

public class DetailsColoured extends AppCompatActivity {

    Button addColBtn;
    EditText ColMale0, ColMale16, ColMale19, ColMale36;
    EditText ColFem0, ColFem16, ColFem19, ColFem36;

    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference myRef = database.getReference("jffcensus-default-rtdb");
    private String emisNum;
    private static final String TAG = "MainActivity";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details_coloured);



        DAOCensus dao = new DAOCensus();

        //COL DEMOGRAPHIC
        addColBtn = findViewById(R.id.btnAddCol);
        ColMale0 =  findViewById(R.id.edtColM0);
        ColMale16 = findViewById(R.id.edtColM16);
        ColMale19 = findViewById(R.id.edtColM19);
        ColMale36 = findViewById(R.id.edtColM36);
        ColFem0 =   findViewById(R.id.edtColF0);
        ColFem16 =  findViewById(R.id.edtColF16);
        ColFem19 =  findViewById(R.id.edtColF19);
        ColFem36 =  findViewById(R.id.edtColF36);

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            emisNum = extras.getString("EMIS");
        }
        ///////////

        //Intended to update relevant data
        addColBtn.setOnClickListener(view ->
        {
            HashMap<String, Object> hashMap = new HashMap<>();
            hashMap.put("colMale0", ColMale0.getText().toString());
            hashMap.put("colMale16",ColMale16.getText().toString());
            hashMap.put("colMale19",ColMale19.getText().toString());
            hashMap.put("colMale36",ColMale36.getText().toString());
            hashMap.put("colFem0",  ColFem0.getText().toString());
            hashMap.put("colFem16", ColFem16.getText().toString());
            hashMap.put("colFem19", ColFem19.getText().toString());
            hashMap.put("colFem36", ColFem36.getText().toString());
            //dao.
            dao.UpdateCol(hashMap, emisNum);

            Toast.makeText(this, "Update Complete!", Toast.LENGTH_SHORT).show();

        });
    }


}
