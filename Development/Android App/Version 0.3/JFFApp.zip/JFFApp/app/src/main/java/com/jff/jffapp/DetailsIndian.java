package com.jff.jffapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;

public class DetailsIndian extends AppCompatActivity {
    Button addIndBtn;
    EditText IndMale0, IndMale16, IndMale19, IndMale36;
    EditText IndFem0, IndFem16, IndFem19, IndFem36;

    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference myRef = database.getReference("jffcensus-default-rtdb");
    private String emisNum;
    private static final String TAG = "MainActivity";
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details_indian);



        DAOCensus dao = new DAOCensus();

        //Ind DEMOGRAPHIC
        addIndBtn = findViewById(R.id.btnAddInd);
        IndMale0 =  findViewById(R.id.edtIndM0);
        IndMale16 = findViewById(R.id.edtIndM16);
        IndMale19 = findViewById(R.id.edtIndM19);
        IndMale36 = findViewById(R.id.edtIndM36);
        IndFem0 =   findViewById(R.id.edtIndF0);
        IndFem16 =  findViewById(R.id.edtIndF16);
        IndFem19 =  findViewById(R.id.edtIndF19);
        IndFem36 =  findViewById(R.id.edtIndF36);

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            emisNum = extras.getString("EMIS");
        }
        ///////////

        //Intended to update relevant data
        addIndBtn.setOnClickListener(view ->
        {
            HashMap<String, Object> hashMap = new HashMap<>();
            hashMap.put("indMale0", IndMale0.getText().toString());
            hashMap.put("indMale16",IndMale16.getText().toString());
            hashMap.put("indMale19",IndMale19.getText().toString());
            hashMap.put("indMale36",IndMale36.getText().toString());
            hashMap.put("indFem0",  IndFem0.getText().toString());
            hashMap.put("indFem16", IndFem16.getText().toString());
            hashMap.put("indFem19", IndFem19.getText().toString());
            hashMap.put("indFem36", IndFem36.getText().toString());
            //dao.
            dao.UpdateInd(hashMap, emisNum);

            Toast.makeText(this, "Update Complete!", Toast.LENGTH_SHORT).show();


        });
        
    }
}