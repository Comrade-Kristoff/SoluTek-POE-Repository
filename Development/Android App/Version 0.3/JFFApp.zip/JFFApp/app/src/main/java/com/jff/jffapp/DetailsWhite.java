package com.jff.jffapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;

public class DetailsWhite extends AppCompatActivity {

    Button addWhiBtn;
    EditText WhiMale0, WhiMale16, WhiMale19, WhiMale36;
    EditText WhiFem0, WhiFem16, WhiFem19, WhiFem36;

    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference myRef = database.getReference("jffcensus-default-rtdb");
    private String emisNum;
    private static final String TAG = "MainActivity";
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details_white);



        DAOCensus dao = new DAOCensus();

        //Whi DEMOGRAPHIC
        addWhiBtn = findViewById(R.id.btnAddWhi);
        WhiMale0 =  findViewById(R.id.edtWhiM0);
        WhiMale16 = findViewById(R.id.edtWhiM16);
        WhiMale19 = findViewById(R.id.edtWhiM19);
        WhiMale36 = findViewById(R.id.edtWhiM36);
        WhiFem0 =   findViewById(R.id.edtWhiF0);
        WhiFem16 =  findViewById(R.id.edtWhiF16);
        WhiFem19 =  findViewById(R.id.edtWhiF19);
        WhiFem36 =  findViewById(R.id.edtWhiF36);

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            emisNum = extras.getString("EMIS");
        }
        ///////////

        //Intended to update relevant data
        addWhiBtn.setOnClickListener(view ->
        {
            HashMap<String, Object> hashMap = new HashMap<>();
            hashMap.put("whiMale0", WhiMale0.getText().toString());
            hashMap.put("whiMale16",WhiMale16.getText().toString());
            hashMap.put("whiMale19",WhiMale19.getText().toString());
            hashMap.put("whiMale36",WhiMale36.getText().toString());
            hashMap.put("whiFem0",  WhiFem0.getText().toString());
            hashMap.put("whiFem16", WhiFem16.getText().toString());
            hashMap.put("whiFem19", WhiFem19.getText().toString());
            hashMap.put("whiFem36", WhiFem36.getText().toString());
            //dao.
            dao.UpdateWhi(hashMap, emisNum);

            Toast.makeText(this, "Update Complete!", Toast.LENGTH_SHORT).show();

        });
        
    }
}