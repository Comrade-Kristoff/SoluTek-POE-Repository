package com.jff.jffapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {



    Button newEntryBtn;
    Button logoutBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        newEntryBtn = findViewById(R.id.btnCreate);
        logoutBtn = findViewById(R.id.logout);

        logoutBtn.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View view) {
            finish();
            System.exit(0);
          }
        });
    }

    public void newEntry(View view){
        Intent intentToCreate = new Intent(MainActivity.this, SchoolDetails.class);
        startActivity((intentToCreate));
    }



    //List will be used to reflect recently added Schools, with Attendee as the Sub Item.
}
