package com.jff.jffapp;

import android.app.Application;

public class saveEMIS extends Application {



    public String getSomeVariable() {
        return someVariable;
    }

    public void setSomeVariable(String someVariable) {
        this.someVariable = someVariable;
    }

    public String someVariable;


}
