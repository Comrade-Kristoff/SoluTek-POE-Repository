package com.jff.jffapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;

public class CatSelect extends AppCompatActivity {

    private String emisNum = "";
    Button afrSelectBtn;
    Button colSelectBtn;
    Button indSelectBtn;
    Button whiSelectBtn;
    Button othSelectBtn;
    Button totals;
    TextView targetTest;
    DatabaseReference dbRef;

    int totalAfr, totalAfrMales, totalAfrFemales;
    int totalCol, totalColMales, totalColFemales;
    int totalInd, totalIndMales, totalIndFemales;
    int totalWhi, totalWhiMales, totalWhiFemales;
    int totalOth, totalOthMales, totalOthFemales;
    int totalMales0, totalMales16, totalMales19, totalMales36;
    int totalFemales0, totalFemales16, totalFemales19, totalFemales36;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cat_select);

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            emisNum = extras.getString("EMIS");
        }

        afrSelectBtn = findViewById(R.id.btnAfrican);
        colSelectBtn = findViewById(R.id.btnColoured);
        indSelectBtn = findViewById(R.id.btnIndian);
        whiSelectBtn = findViewById(R.id.btnWhite);
        othSelectBtn = findViewById(R.id.btnOther);
        targetTest = findViewById(R.id.tvTest);
        totals = findViewById(R.id.btnTotalSum);

        Intent get = getIntent();
        String text = get.getStringExtra(SchoolDetails.EMIS_TAG);

        targetTest.setText(text);
        DAOCensus dao = new DAOCensus();
//


        FirebaseDatabase db = FirebaseDatabase.getInstance();
        dbRef = db.getReference(Census.class.getSimpleName()).child(emisNum);



        //=============================================================//
        dbRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists())
                {
                    String TEXT_afrMale0  = snapshot.child("afrMale0").getValue().toString();
                    String TEXT_afrMale16 = snapshot.child("afrMale16").getValue().toString();
                    String TEXT_afrMale19 = snapshot.child("afrMale19").getValue().toString();
                    String TEXT_afrMale36 = snapshot.child("afrMale36").getValue().toString();

                    String TEXT_afrFemale0  = snapshot.child("afrFem0").getValue().toString();
                    String TEXT_afrFemale16 = snapshot.child("afrFem16").getValue().toString();
                    String TEXT_afrFemale19 = snapshot.child("afrFem19").getValue().toString();
                    String TEXT_afrFemale36 = snapshot.child("afrFem36").getValue().toString();

                    totalAfr =
                              Integer.parseInt(TEXT_afrMale0)
                            + Integer.parseInt(TEXT_afrMale16)
                            + Integer.parseInt(TEXT_afrMale19)
                            + Integer.parseInt(TEXT_afrMale36)
                            + Integer.parseInt(TEXT_afrFemale0)
                            + Integer.parseInt(TEXT_afrFemale16)
                            + Integer.parseInt(TEXT_afrFemale19)
                            + Integer.parseInt(TEXT_afrFemale36);


                    
                    
                    ///

                    String TEXT_colMale0  = snapshot.child("colMale0").getValue().toString();
                    String TEXT_colMale16 = snapshot.child("colMale16").getValue().toString();
                    String TEXT_colMale19 = snapshot.child("colMale19").getValue().toString();
                    String TEXT_colMale36 = snapshot.child("colMale36").getValue().toString();

                    String TEXT_colFemale0  = snapshot.child("colFem0").getValue().toString();
                    String TEXT_colFemale16 = snapshot.child("colFem16").getValue().toString();
                    String TEXT_colFemale19 = snapshot.child("colFem19").getValue().toString();
                    String TEXT_colFemale36 = snapshot.child("colFem36").getValue().toString();

                    totalCol =
                              Integer.parseInt(TEXT_colMale0)
                            + Integer.parseInt(TEXT_colMale16)
                            + Integer.parseInt(TEXT_colMale19)
                            + Integer.parseInt(TEXT_colMale36)
                            + Integer.parseInt(TEXT_colFemale0)
                            + Integer.parseInt(TEXT_colFemale16)
                            + Integer.parseInt(TEXT_colFemale19)
                            + Integer.parseInt(TEXT_colFemale36);


                    
                //

                    String TEXT_indMale0  = snapshot.child("indMale0").getValue().toString();
                    String TEXT_indMale16 = snapshot.child("indMale16").getValue().toString();
                    String TEXT_indMale19 = snapshot.child("indMale19").getValue().toString();
                    String TEXT_indMale36 = snapshot.child("indMale36").getValue().toString();

                    String TEXT_indFemale0  = snapshot.child("indFem0").getValue().toString();
                    String TEXT_indFemale16 = snapshot.child("indFem16").getValue().toString();
                    String TEXT_indFemale19 = snapshot.child("indFem19").getValue().toString();
                    String TEXT_indFemale36 = snapshot.child("indFem36").getValue().toString();

                    totalInd =
                            Integer.parseInt(TEXT_indMale0)
                                    + Integer.parseInt(TEXT_indMale16)
                                    + Integer.parseInt(TEXT_indMale19)
                                    + Integer.parseInt(TEXT_indMale36)
                                    + Integer.parseInt(TEXT_indFemale0)
                                    + Integer.parseInt(TEXT_indFemale16)
                                    + Integer.parseInt(TEXT_indFemale19)
                                    + Integer.parseInt(TEXT_indFemale36);



//


                    String TEXT_whiMale0  = snapshot.child("whiMale0").getValue().toString();
                    String TEXT_whiMale16 = snapshot.child("whiMale16").getValue().toString();
                    String TEXT_whiMale19 = snapshot.child("whiMale19").getValue().toString();
                    String TEXT_whiMale36 = snapshot.child("whiMale36").getValue().toString();

                    String TEXT_whiFemale0  = snapshot.child("whiFem0").getValue().toString();
                    String TEXT_whiFemale16 = snapshot.child("whiFem16").getValue().toString();
                    String TEXT_whiFemale19 = snapshot.child("whiFem19").getValue().toString();
                    String TEXT_whiFemale36 = snapshot.child("whiFem36").getValue().toString();

                    totalWhi =
                            Integer.parseInt(TEXT_whiMale0)
                                    + Integer.parseInt(TEXT_whiMale16)
                                    + Integer.parseInt(TEXT_whiMale19)
                                    + Integer.parseInt(TEXT_whiMale36)
                                    + Integer.parseInt(TEXT_whiFemale0)
                                    + Integer.parseInt(TEXT_whiFemale16)
                                    + Integer.parseInt(TEXT_whiFemale19)
                                    + Integer.parseInt(TEXT_whiFemale36);



//

                    String TEXT_othMale0  = snapshot.child("othMale0").getValue().toString();
                    String TEXT_othMale16 = snapshot.child("othMale16").getValue().toString();
                    String TEXT_othMale19 = snapshot.child("othMale19").getValue().toString();
                    String TEXT_othMale36 = snapshot.child("othMale36").getValue().toString();

                    String TEXT_othFemale0  = snapshot.child("othFem0").getValue().toString();
                    String TEXT_othFemale16 = snapshot.child("othFem16").getValue().toString();
                    String TEXT_othFemale19 = snapshot.child("othFem19").getValue().toString();
                    String TEXT_othFemale36 = snapshot.child("othFem36").getValue().toString();

                    totalOth =
                            Integer.parseInt(TEXT_othMale0)
                                    + Integer.parseInt(TEXT_othMale16)
                                    + Integer.parseInt(TEXT_othMale19)
                                    + Integer.parseInt(TEXT_othMale36)
                                    + Integer.parseInt(TEXT_othFemale0)
                                    + Integer.parseInt(TEXT_othFemale16)
                                    + Integer.parseInt(TEXT_othFemale19)
                                    + Integer.parseInt(TEXT_othFemale36);

            totalMales0 = Integer.parseInt(TEXT_afrMale0)
                        + Integer.parseInt(TEXT_colMale0)
                        + Integer.parseInt(TEXT_indMale0)
                        + Integer.parseInt(TEXT_whiMale0)
                        + Integer.parseInt(TEXT_othMale0);

            totalMales16 = Integer.parseInt(TEXT_afrMale16)
                        + Integer.parseInt(TEXT_colMale16)
                        + Integer.parseInt(TEXT_indMale16)
                        + Integer.parseInt(TEXT_whiMale16)
                        + Integer.parseInt(TEXT_othMale16);

            totalMales19 = Integer.parseInt(TEXT_afrMale19)
                        + Integer.parseInt(TEXT_colMale19)
                        + Integer.parseInt(TEXT_indMale19)
                        + Integer.parseInt(TEXT_whiMale19)
                        + Integer.parseInt(TEXT_othMale19);

            totalMales36 = Integer.parseInt(TEXT_afrMale36)
                        + Integer.parseInt(TEXT_colMale36)
                        + Integer.parseInt(TEXT_indMale36)
                        + Integer.parseInt(TEXT_whiMale36)
                        + Integer.parseInt(TEXT_othMale36);


                totalFemales0 = Integer.parseInt(TEXT_afrFemale0)
                            + Integer.parseInt(TEXT_colFemale0)
                            + Integer.parseInt(TEXT_indFemale0)
                            + Integer.parseInt(TEXT_whiFemale0)
                            + Integer.parseInt(TEXT_othFemale0);

                totalFemales16 = Integer.parseInt(TEXT_afrFemale16)
                            + Integer.parseInt(TEXT_colFemale16)
                            + Integer.parseInt(TEXT_indFemale16)
                            + Integer.parseInt(TEXT_whiFemale16)
                            + Integer.parseInt(TEXT_othFemale16);

                totalFemales19 = Integer.parseInt(TEXT_afrFemale19)
                            + Integer.parseInt(TEXT_colFemale19)
                            + Integer.parseInt(TEXT_indFemale19)
                            + Integer.parseInt(TEXT_whiFemale19)
                            + Integer.parseInt(TEXT_othFemale19);

                totalFemales36 = Integer.parseInt(TEXT_afrFemale36)
                            + Integer.parseInt(TEXT_colFemale36)
                            + Integer.parseInt(TEXT_indFemale36)
                            + Integer.parseInt(TEXT_whiFemale36)
                            + Integer.parseInt(TEXT_othFemale36);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
//
            }
        });
        ///

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


        //==============================================================//


        totals.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                HashMap<String, Object> hashMap = new HashMap<>();
                hashMap.put("totalMale0", totalMales0);
                hashMap.put("totalMale16", totalMales16);
                hashMap.put("totalMale19", totalMales19);
                hashMap.put("totalMale36", totalMales36);

                hashMap.put("totalFem0", totalFemales0);
                hashMap.put("totalFem16", totalFemales16);
                hashMap.put("totalFem19", totalFemales19);
                hashMap.put("totalFem36", totalFemales36);

                hashMap.put("totalAfr", totalAfr);
                hashMap.put("totalCol", totalCol);
                hashMap.put("totalInd", totalInd);
                hashMap.put("totalWhi", totalWhi);
                hashMap.put("totalOth", totalOth);

                //dao.
                dao.UpdateTotals(hashMap, emisNum);

                Toast.makeText(getApplicationContext(), "Update Complete!", Toast.LENGTH_SHORT).show();
            }
        });


    }

    public void ToAfrDetails(View view){
        Intent toAfr = new Intent(CatSelect.this, DetailsAfrican.class);
        toAfr.putExtra("EMIS", emisNum);
        startActivity((toAfr));
    }

    public void ToColDetails(View view){
        Intent toCol = new Intent(CatSelect.this, DetailsColoured.class);
        toCol.putExtra("EMIS", emisNum);
        startActivity((toCol));
    }

    public void ToIndDetails(View view){
        Intent toInd = new Intent(CatSelect.this, DetailsIndian.class);
        toInd.putExtra("EMIS", emisNum);
        startActivity((toInd));
    }

    public void ToWhiDetails(View view){
        Intent toWhi = new Intent(CatSelect.this, DetailsWhite.class);
        toWhi.putExtra("EMIS", emisNum);
        startActivity((toWhi));
    }

    public void ToOthDetails(View view){
        Intent toOth = new Intent(CatSelect.this, DetailsOther.class);
        toOth.putExtra("EMIS", emisNum);
        startActivity((toOth));
    }
}