package com.jff.jffapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.Exclude;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.IgnoreExtraProperties;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.Map;

public class DetailsAfrican extends AppCompatActivity {

    Button addAfrBtn;
    EditText afrMale0, afrMale16, afrMale19, afrMale36;
    EditText afrFem0, afrFem16, afrFem19, afrFem36;

    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference dbRef;
    private String emisNum;
    private static final String TAG = "MainActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details_african);
        DAOCensus dao = new DAOCensus();

        //AFRICAN DEMOGRAPHIC
        addAfrBtn  = findViewById(R.id.btnAddAfr);
        afrMale0   =  findViewById(R.id.edtAfrM0);
        afrMale16  = findViewById(R.id.edtAfrM16);
        afrMale19  = findViewById(R.id.edtAfrM19);
        afrMale36  = findViewById(R.id.edtAfrM36);
        afrFem0    =   findViewById(R.id.edtAfrF0);
        afrFem16   =  findViewById(R.id.edtAfrF16);
        afrFem19   =  findViewById(R.id.edtAfrF19);
        afrFem36   =  findViewById(R.id.edtAfrF36);



///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            emisNum = extras.getString("EMIS");
        }
        ///
        FirebaseDatabase db = FirebaseDatabase.getInstance();
        dbRef = db.getReference(Census.class.getSimpleName()).child(emisNum);

    //  dbRef.addValueEventListener(new ValueEventListener() {
    //      @Override
    //      public void onDataChange(@NonNull DataSnapshot snapshot) {

    //             if (snapshot.exists())
    //             {
    //                  String TEXT_afrMale0  = snapshot.child("afrMale0").getValue().toString();
    //                 String TEXT_afrMale16 = snapshot.child("afrMale16").getValue().toString();
    //                 String TEXT_afrMale19 = snapshot.child("afrMale19").getValue().toString();
    //                 String TEXT_afrMale36 = snapshot.child("afrMale36").getValue().toString();

    //                  String TEXT_afrFemale0  = snapshot.child("afrFem0").getValue().toString();
    //                 String TEXT_afrFemale16 = snapshot.child("afrFem16").getValue().toString();
    //                 String TEXT_afrFemale19 = snapshot.child("afrFem19").getValue().toString();
    //                 String TEXT_afrFemale36 = snapshot.child("afrFem36").getValue().toString();


    //                 if (!TEXT_afrMale0.equals("0"))
    //                 {
    //                     afrMale0.setText(TEXT_afrMale0);
    //                     afrMale16.setText(TEXT_afrMale16);
    //                     afrMale19.setText(TEXT_afrMale19);
    //                     afrMale36.setText(TEXT_afrMale36);
    //                     afrFem0.setText(TEXT_afrFemale0);
    //                     afrFem16.setText(TEXT_afrFemale16);
    //                     afrFem19.setText(TEXT_afrFemale19);
    //                     afrFem36.setText(TEXT_afrFemale36);
    //                 }


    //             }
    //         }



    //      @Override
    //      public void onCancelled(@NonNull DatabaseError error) {
//
    //      }
    //  });
    //  ///

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        ///////////

        //Intended to update relevant data
        addAfrBtn.setOnClickListener(view ->
        {
            HashMap<String, Object> hashMap = new HashMap<>();
            hashMap.put("afrMale0", afrMale0.getText().toString());
            hashMap.put("afrMale16",afrMale16.getText().toString());
            hashMap.put("afrMale19",afrMale19.getText().toString());
            hashMap.put("afrMale36",afrMale36.getText().toString());
            hashMap.put("afrFem0",  afrFem0.getText().toString());
            hashMap.put("afrFem16", afrFem16.getText().toString());
            hashMap.put("afrFem19", afrFem19.getText().toString());
            hashMap.put("afrFem36", afrFem36.getText().toString());
            //dao.
            dao.UpdateAfr(hashMap, emisNum);

            Toast.makeText(this, "Update Complete!", Toast.LENGTH_SHORT).show();

        });
    }



}